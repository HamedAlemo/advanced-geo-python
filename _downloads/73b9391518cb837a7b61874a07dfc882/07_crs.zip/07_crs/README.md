# Working with CRS and Projections in Python

This repository contains a notebook named `crs_python.ipynb` which is chapter #7 of the course book for the [Advanced Geospatial Analytics w Python](https://hamedalemo.github.io/advanced-geo-python/) in Fall 2024.

## How to Run
- Create a new conda environment using the `environment.yml` file. 
```
conda env create -f environment.yml
```
- Activate the new conda conda environment
```
conda activate crs-lecture
```
- Run Jupyter Lab
```
jupyter lab
```
- Open `crs_python.ipynb` and run all the cells.
